# Un premier petit projet Android

## d'abord l'accueil

![accueil](accueil.png)

## le calcul

![classic](classic.png)

## et la mega fonction

![plus](fctplus.png)
